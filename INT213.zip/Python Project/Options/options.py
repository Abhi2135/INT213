from tkinter import *

def main(name):

    #when user will select any option then function will be called with different parameter
    def option(num):
        if num==1:                                #if the num is 1
            root.destroy()                        #destroy the current window
            from Options import animal            #import animal
            animal.main(name)                         #main function of animal will be called

        if num==2:                                #if the num is 2
            root.destroy()                        #destroy the current window
            from Options import fruits            #import fruits
            fruits.main(name)                         #main function of fruits will be called


        if num==3:                                #if the num is 3
            root.destroy()                        #destroy the current window
            from Options import birds             #import birds
            birds.main(name)                          #main function of birds will be called

        if num == 4:                              #if the num is 4
            root.destroy()                        #destroy the current window
            from Options import instrument        #import instrunment
            instrument.main(name)                     #main function of instrument will be called

        if num==5:                                #if the num is 5
            root.destroy()                        #destroy the current window
            from Options import cars              #import cars
            cars.main(name)                           #main function of cars will be called

        if num==6:                                #if the num is 6
            root.destroy()                        #destroy the current window
            from Options import countries         #import countries
            countries.main(name)                      #main function of countries will be called




    root = Tk()                                          #creating a new window
    root.geometry("500x500+500+150")                     #definig its geometry and its place
    root.title("Scrambler")                              #Adding titile to the window
    root.configure(background='#FF8C00')                 #giving window background color
    root.resizable(0, 0)                                 #stoping it from getting resized
    img = PhotoImage(file="D:\Python Project/logo.png")  #importing a image
    root.iconphoto(True, img)                            #using the image as an icon for the window

    Label(root, text='Hi! '+name, font=("", 30, 'bold'), bg='#FF8C00').grid(row=0, column=0, columnspan=2,padx=10, pady=10)

    #Placing a lablel asking user to select the options
    Label(root,text='Select the option',font=("", 30,'bold'),bg='#FF8C00').grid(row=1,column=0,columnspan=2,padx=10,pady=50)


    #inserting different buttons for different options for user to choose
    option1=Button(root, text='Animals', width=16, borderwidth=5, font=("", 15), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=lambda: option(1))
    option2=Button(root, text='Fruits And Veggies', width=16, borderwidth=5, font=("", 15), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=lambda: option(2))
    option3=Button(root, text='Birds and Fishes', width=16, borderwidth=5, font=("", 15), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=lambda: option(3))
    option4=Button(root, text='Musical Instruments', width=16, borderwidth=5, font=("", 15), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=lambda: option(4))
    option5=Button(root, text='Cars', width=16, borderwidth=5, font=("", 15), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=lambda: option(5))
    option6=Button(root, text='Countries', width=16, borderwidth=5, font=("", 15), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=lambda: option(6))


    #placing the buttons on their positon
    option1.grid(row=3,column=0,padx=30,pady=10)
    option2.grid(row=3,column=1,padx=30,pady=10)
    option3.grid(row=4,column=0,padx=30,pady=10)
    option4.grid(row=4,column=1,padx=30,pady=00)
    option5.grid(row=5,column=0,padx=30,pady=10)
    option6.grid(row=5,column=1,padx=30,pady=10)


    root.mainloop()