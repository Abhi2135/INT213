from tkinter import *                 #importing tkinter module
from tkinter import messagebox        #importing messagebox


#assigning jumbled word for musical instrument
options_word = [ 'NASPOHOXE' , 'AILTNERC' , 'BAUT' , 'TOERABUIMN' , 'ZETNSRYHESI' , 'OOBE' , 'IAROANMHC' , 'AMIBMAR' , 'IAOONRCDC' , 'ELFTU' ,
                 'HXEYNOOPL' , 'BPRIEAGP' , 'PAHR' , 'LLEEKUU' , 'JAONB' , 'PSODARCHIRH' , 'OLCEL' , 'OSNOBSA' , 'RIATS' , 'RITAGU' ]

#giving the answers for the jumbled word
options_ans = [ 'SAXOPHONE' , 'CLARINET' , 'TUBA' , 'TAMBOURINE' , 'SYNTHESIZER' , 'OBOE' , 'HARMONICA' , 'MARIMBA' , 'ACCORDION' , 'FLUTE' ,
                'XYLOPHONE' , 'BAGPIPER' , 'HARP' , 'UKULELE' , 'BANJO' , 'HARPSICHORD' , 'CELLO' , 'BASSOON' , 'SITAR' , 'GUITAR' ]


num = 0                                                      #assiggning num to call words and answer with their index
jumbled_rand_word = options_word[num]                        #initialising random words
points = 0                                                   #initialising point as 0 to keep track of points of user


def main(name):
    #this function will show the score of the user
    def show_score():
        global points                                       #initialising point as global
        user_word = get_input.get().upper()                 #giving user a random word
        # checking the input of the user in correct or not
        if user_word == options_ans[num]:                   #if correct
            points += 5                                     #points will be increased by 5
            score.configure(text="Score:- " + str(points))  #update the score
            messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")     #message box will appear saying correct answer
            word.configure(text=options_word[num])          #next jumbled word will appear
            get_input.delete(0, END)                        #delete the word that is previously entered by the user
            ans_lab.configure(text="")                      #this function will remove the previous ans if it is their
            root.destroy()                                  #it will destroy the current root window
            from Options import finish_page                 #it will import the finish_page moduke
            finish_page.main(name,points)                        #main function of finish_page will be called and passing the points

        else:                                              #if not correct
            messagebox.showerror("Error", "Incorrect Answer..Try your best!")   #message box appear saying incorrect answer
            get_input.delete(0, END)                       #delete the word that is previously entered by the user



    #change function will be called when the user will click on the change butoon
    def change():
        global num                                        #initialising num as global variable
        #checking if the index is greater than 18
        if num<18:
            num = num+1
            word.configure  (text=options_word[num])
            get_input.delete(0, END)
            ans_lab.configure(text="")
        else:
            next.configure(text="Finish",command=show_score)

    def check():
        global points, num
        if num<18:   #if yes
            # it will check the word entered by ues is correct or not
            user_word = get_input.get().upper()
            if user_word == options_ans[num]:
                points += 5
                score.configure(text="Score:- " + str(points))
                messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")
                num = num+1
                word.configure(text=options_word[num])
                get_input.delete(0, END)
                ans_lab.configure(text="")
            else:
                messagebox.showerror("Error", "Incorrect Answer..Try your best!")
                get_input.delete(0, END)
        else:      #if no
            #it will check the word entered by ues is correct or not
            user_word = get_input.get().upper()
            if user_word == options_ans[num]:
                points += 5
                score.configure(text="Score:- " + str(points))
                messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")
                num = num + 1
                word.configure(text=options_word[num])
                get_input.delete(0, END)
                ans_lab.configure(text="")
            else:
                messagebox.showerror("Error", "Incorrect Answer..Try your best!")
                get_input.delete(0, END)
            #it will change the next button to the finish button
            next.configure(text="Finish", command=show_score)
    #this function will be called when the user will click on answer
    def show_answer():
        global points
        #it will check if the point is greater than 4 or not
        if points > 4: # if it is greater than 4
            points -= 5                                     #the points will be decreased by 5
            score.configure(text="Score:- " + str(points))  #score will be updated
            ans_lab.configure(text=options_ans[num])        #the answer for the word will be shown
        else:        #if it is not enough
            ans_lab.configure(text='Not enough points')     # the message box will appear saying not enough point

    root = Tk()                                          #creating a new window
    root.geometry("500x500+500+150")                     #definig its geometry and its place
    root.resizable(0, 0)                                 #stoping it from getting resized
    root.title("Scrambler")                              #Adding titile to the window
    root.configure(background="#FF8C00")                 #giving window background color
    img = PhotoImage(file="D:\Python Project/logo.png")  #importing a image
    root.iconphoto(True, img)                            #using the image as an icon for the window


    #placing a label to show score
    score = Label(text="Score:- 0",pady=10,bg="#FF8C00",fg="#000000",font="Titillium  14 bold")
    score.pack(anchor="n")

    #placing a label to show the jumbled word
    word = Label(text=jumbled_rand_word,pady=10,bg="#FF8C00",fg="#000000",font="Titillium  50 bold")
    word.pack()

    #placing a entry to take input for answer from user
    get_input = Entry(font="none 26 bold",borderwidth=10,justify='center')
    get_input.pack()

    #placing the next button that will check if the given answer is right or not and increase the points
    next = Button(text="Next",width=18,borderwidth=8,font=("", 13),fg="#FFFFFF",bg="#4169E1",command=check)
    next.pack(pady=(10, 20))

    #placing the change button to change the option when the user is stucked
    change = Button(text="Change Word",width=18,borderwidth=8,fg="#FFFFFF",bg="#4169E1",font=("", 13), command=change)
    change.pack()

    #placing the answer butoon so that user can get a hint
    ans = Button(text="Answer", width=18,borderwidth=8,fg="#FFFFFF",bg="#4169E1",font=("", 13),command=show_answer)
    ans.pack(pady=(20, 10))

    # placing label to show answer
    ans_lab = Label(text="",bg="#FF8C00",fg="#000000",font="Courier 15 bold")
    ans_lab.pack()

    # placing quite button to close the quiz
    quit=Button(root, text='Quit', width=5, borderwidth=5, font=("", 9), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=root.destroy)
    quit.pack(anchor=NE,pady=10)

    root.mainloop()