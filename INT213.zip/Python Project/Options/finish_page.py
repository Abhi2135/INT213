from tkinter import *                 #importing tkinter module
from tkinter import messagebox        #importing messagebox



def main(name,points=0):

    #this functionn will be called when the user will click on home page button
    def main_menu():
        root.destroy()     #destroy the current window
        import Main        #import Main
        Main.main()        #call main functonof Main module




    root = Tk()                                          #creating a new window
    root.geometry("500x500+500+150")                     #definig its geometry and its place
    root.resizable(0, 0)                                 #stoping it from getting resized
    root.title("Scrambler")                              #Adding titile to the window
    root.configure(background="#FF8C00")                 #giving window background color
    img = PhotoImage(file="D:\Python Project/logo.png")  #importing a image
    root.iconphoto(True, img)                            #using the image as an icon for the window

    Label(text='Congrats! '+name, bg="#FF8C00", fg="#000000", font="Titillium  30 bold").pack(pady=10)

    #Showing Score written on the window
    Label(text='Score', bg="#FF8C00", fg="#000000", font="Titillium  40 bold").pack(pady=10)

    #Displaying the points that is scored by user
    Label(text=points, bg="#FF8C00", fg="#000000", font="Titillium  40 bold").pack(pady=20)

    #Adding a button to return back to home page
    Button(root, text='Home page', width=20, borderwidth=8, font=("", 13), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=main_menu).pack(pady=5,)

    #adding a button to quit the program
    Button(root, text='Quit', width=5, borderwidth=5, font=("", 9), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=root.destroy).pack(anchor=SE,pady=65)




    root.mainloop()