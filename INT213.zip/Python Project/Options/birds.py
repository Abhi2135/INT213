from tkinter import *
from tkinter import messagebox

options_word = [ 'RCANLAID' , 'FAOMLNGI' , 'DSWORSHFI' , 'NUBIRHMGDMI' , 'AHIRAPN' , 'AMOEKARDWL' , 'NLICPEA' , 'BRCAAUDAR' , 'HIENKSRGFI' ,
                 'LCLOOKP' , 'OEKDPCWORE' , 'UTEURVL' , 'NAOMLS' , 'RRWSAPO' , 'OLNO' , 'OGSOE' , 'NRHOE' , 'GHEIGFITSRR' , 'UYKTER' , 'ESAEAPLLRC' ]


options_ans = [ 'CARDINAL' , 'FLAMINGO' , 'SWORDFISH' , 'HUMMINGBIRD' , 'PIRANHA' , 'MEADOWLARK' , 'PELICAN' , 'BARRACUDA' , 'KINGFISHER' ,
                'POLLOCK' , 'WOODPECKER' , 'VULTURE' ,"SALMON" , 'SPARROW' , 'LOON' , 'GOOSE' , 'HERON' , 'TRIGGERFISH' , 'TURKEY' , 'PEARLSCALE' ]


num = 0
jumbled_rand_word = options_word[num]

points = 0


def main(name):

    def show_score():
        global points
        user_word = get_input.get().upper()
        if user_word == options_ans[num]:
            points += 5
            score.configure(text="Score:- " + str(points))
            messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")
            word.configure(text=options_word[num])
            get_input.delete(0, END)
            ans_lab.configure(text="")
            root.destroy()
            from Options import finish_page
            finish_page.main(name,points)

        else:
            messagebox.showerror("Error", "Inorrect Answer..Try your best!")
            get_input.delete(0, END)




    def change():
        global num

        if num<18:
            num = num+1
            word.configure  (text=options_word[num])
            get_input.delete(0, END)
            ans_lab.configure(text="")
        else:
            next.configure(text="Finish",command=show_score)

    def check():
        global points, num
        if num<18:
            user_word = get_input.get().upper()
            if user_word == options_ans[num]:
                points += 5
                score.configure(text="Score:- " + str(points))
                messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")
                num = num+1
                word.configure(text=options_word[num])
                get_input.delete(0, END)
                ans_lab.configure(text="")
            else:
                messagebox.showerror("Error", "Inorrect Answer..Try your best!")
                get_input.delete(0, END)
        else:
            user_word = get_input.get().upper()
            if user_word == options_ans[num]:
                points += 5
                score.configure(text="Score:- " + str(points))
                messagebox.showinfo('correct', "Correct Answer.. Keep it Up!")
                num = num + 1
                word.configure(text=options_word[num])
                get_input.delete(0, END)
                ans_lab.configure(text="")
            else:
                messagebox.showerror("Error", "Inorrect Answer..Try your best!")
                get_input.delete(0, END)
            next.configure(text="Finish", command=show_score)

    def show_answer():
        global points
        if points > 4:
            points -= 5
            score.configure(text="Score:- " + str(points))
            ans_lab.configure(text=options_ans[num])
        else:
            ans_lab.configure(text='Not enough points')

    root = Tk()
    root.geometry("500x500+500+150")
    root.resizable(0, 0)
    root.title("Scrambler")
    root.configure(background="#FF8C00")
    img = PhotoImage(file="D:\Python Project/logo.png")
    root.iconphoto(True, img)

    score = Label(text="Score:- 0",pady=10,bg="#FF8C00",fg="#000000",font="Titillium  14 bold")
    score.pack(anchor="n")

    word = Label(text=jumbled_rand_word,pady=10,bg="#FF8C00",fg="#000000",font="Titillium  50 bold")
    word.pack()

    get_input = Entry(font="none 26 bold",borderwidth=10,justify='center')
    get_input.pack()

    next = Button(text="Next",width=18,borderwidth=8,font=("", 13),fg="#FFFFFF",bg="#4169E1",command=check)
    next.pack(pady=(10, 20))

    change = Button(text="Change Word",width=18,borderwidth=8,fg="#FFFFFF",bg="#4169E1",font=("", 13), command=change)
    change.pack()

    ans = Button(text="Answer", width=18,borderwidth=8,fg="#FFFFFF",bg="#4169E1",font=("", 13),command=show_answer)
    ans.pack(pady=(20, 10))

    ans_lab = Label(text="",bg="#FF8C00",fg="#000000",font="Courier 15 bold")
    ans_lab.pack()

    quit = Button(root, text='Quit', width=5, borderwidth=5, font=("", 9), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=root.destroy)
    quit.pack(anchor=NE, pady=10)

    root.mainloop()
