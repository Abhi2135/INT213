from tkinter import *      #importing tkinter module
import tkinter as tk
from tkinter import messagebox
def main():
    #start buttonn will be called  when user will click on start button which will destroy b1 and b2 and call option function
    def start():
        b1.destroy()        #destroying start button
        b2.destroy()        #destroying quit button
        options()
    #option function will be called by start functon and it will ask user to enter name
    def options():
        global mystring
        mystring = tk.StringVar(root)
        l1 = Label(root, text='Enter name', width=18, font=("", 15), fg="#000000", bg="#FF8C00", cursor="hand2")
        l1.place(x=150,y=200)
        e1 = Entry(root,width=25, borderwidth=5,textvariable = mystring,font='TIMES,20',justify=CENTER, relief=GROOVE)    #taking name from the user
        e1.place(x=105, y=235)
        # button b3 will call the start_game function
        b3=Button(root,text='Start Game',width=14, borderwidth=5, font=("", 15), fg="#ffffff", bg="#4169E1", cursor="hand2",command=start_game)
        b3.place(x=170,y=280)
    #start_game function will import option from Option folder
    def start_game():
        global mystring
        var=mystring.get()
        if var!="":
            root.destroy()                               #destroying root
            from Options import options                  #importing options
            options.main(var)                            #calling main funtion of options
        else:
            messagebox.showerror("Enter name", "Please enter your name")

    root = Tk()                                          #creating a new window
    root.geometry("500x500+500+150")                     #definig its geometry and its place
    root.title("Scrambler")                              #Adding titile to the window
    root.configure(background='#FF8C00')                 #giving window background color
    root.resizable(0, 0)                                 #stoping it from getting resized



    #importing a image
    img0 = PhotoImage(file="D:\Python Project/logo.png")

    #using the image as an icon for the window
    root.iconphoto(True,img0)


    #placing the image on the root window
    img=Label(root,image=img0, bg='#e6fff5')
    img.place(x=175,y=10)


    #placing a start button on the root window
    b1 = Button(root, text='Start', width=20, borderwidth=8, font=("", 13), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=start)
    b1.place(x=150, y=250)

    #placing quite button to close the quiz
    b2 = Button(root, text='Quit', width=5, borderwidth=5, font=("", 9), fg="#FFFFFF", bg="#4169E1", cursor="hand2",command=root.destroy)
    b2.place(x=446, y=465)

    root.mainloop()



#calling the main function to run teh code
main()