#create connection with mysql
import mysql.connector
mb=mysql.connector.connect(
host="localhost",
user="root",
password="abhiyanshu"
)
print(mb)
if (-mb.is_connected()):
    print("Connected!!")
else:
    print("Not connected!!")
